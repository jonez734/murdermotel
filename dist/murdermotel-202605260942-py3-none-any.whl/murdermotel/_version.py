__version__ = "0.0.0.dev202605260942"
githash = "75b4d91575ff632c"
datestamp = "202605260942"
