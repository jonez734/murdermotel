#!/bin/sh

python -W all -m "murdermotel" "$@"
