__version__ = "0.0.0.dev202605260941"
githash = "75b4d91575ff632c"
datestamp = "202605260941"
