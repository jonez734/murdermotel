from bbsengine6 import io, util
from . import _version as _version, lib


def init(args, **kw: dict) -> bool:
    io.register_emojis({"robot": "\U0001f916"})
    return True


def access(args, op: str, **kw: dict) -> bool:
    return True


def buildargs(args, **kw: dict) -> None:
    return None


def main(args, **kw: dict):
    util.heading("murder motel")
    lib.runmodule(args, "run", "lobby")
    return True
