from bbsengine6 import database, io, util
from . import _version as _version, lib


def init(args, **kw: dict) -> bool:
    io.register_emojis({"robot": "\U0001f916"})
    return True


def access(args, op: str, **kw: dict) -> bool:
    return True


def buildargs(args, **kw: dict) -> None:
    return None


def main(args, **kw: dict):
    util.heading("murder motel")
    pool = kw.get("pool")
    if pool is None:
        with database.getpool(args) as pool:
            lib.runmodule(args, "run", "lobby", pool=pool)
    else:
        lib.runmodule(args, "run", "lobby", pool=pool)
    return True
